package com.bharat.heritage;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
