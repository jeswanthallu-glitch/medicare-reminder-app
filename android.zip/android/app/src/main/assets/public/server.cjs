var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_genai = require("@google/genai");
import_dotenv.default.config();
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json({ limit: "10mb" }));
var aiClient = null;
function getAIClient() {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new import_genai.GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return aiClient;
}
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
});
app.post("/api/chat", async (req, res) => {
  try {
    const { message, currentState, language = "en", history = [] } = req.body;
    if (!message || typeof message !== "string") {
      res.status(400).json({ error: "Message is required" });
      return;
    }
    const client = getAIClient();
    const systemPrompt = `You are "Bharat Guide", an enthusiastic, deeply knowledgeable, respectful, and friendly cultural guide for the educational platform "Bharat Heritage \u2013 Our Culture, Our Family".
Your mission is to help people, especially students and younger generations, understand, appreciate, and cherish the profound diversity, traditions, festivals, temples, architecture, classical & folk dances, clothing, food, and history of India.

Guidelines:
- Tone: Warm, respectful, inspiring, educational, and family-oriented.
- Context: Current state focus: ${currentState || "General Bharat / India"}. User language: ${language}.
- Answer language: Respond naturally in the requested language (if Telugu: use natural Telugu script; if Hindi: use Devanagari script; if English: use English). You may provide key cultural terms in their native pronunciation/spelling.
- Format: Keep answers clear, engaging, structured with bullet points where helpful, around 120-220 words so it is easy to read and listen to via Text-to-Speech.
- Content integrity: Always uphold respect for all traditions, celebrating unity in diversity ("Vasudhaiva Kutumbakam").
- When asked about temples or Hindu heritage, explain their architectural marvels, historical context, community significance, and cultural preservation roles respectfully.`;
    if (client) {
      const chatContents = [];
      if (Array.isArray(history)) {
        for (const item of history.slice(-4)) {
          if (item.sender === "user") {
            chatContents.push({ role: "user", parts: [{ text: item.text }] });
          } else if (item.sender === "assistant") {
            chatContents.push({ role: "model", parts: [{ text: item.text }] });
          }
        }
      }
      chatContents.push({
        role: "user",
        parts: [{ text: `Current state context: ${currentState || "India"}. Question: ${message}` }]
      });
      const response = await client.models.generateContent({
        model: "gemini-3.8-flash",
        contents: chatContents,
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.7
        }
      });
      const text = response.text || "Bharat is a land of timeless traditions and profound heritage. Let us explore together!";
      res.json({ reply: text, source: "gemini" });
      return;
    }
    const fallbackAnswers = {
      andhra: `Andhra Pradesh is a majestic state celebrated as the "Rice Bowl of India" and home to the classical dance form Kuchipudi. Its cultural tapestry features ancient handlooms like Kalamkari, sacred temples such as Tirumala Venkateswara and Lepakshi with its hanging pillar, and vibrant festivals like Ugadi and Sankranti. The state's cuisine is legendary for spicy Gongura pachadi and Pootarekulu sweet!`,
      telangana: `Telangana boasts a splendid heritage rooted in the Kakatiya dynasty and Deccan heritage. Key highlights include the UNESCO World Heritage Ramappa Temple (known for floating bricks), the Thousand Pillar Temple in Warangal, the colorful flower festival of Bathukamma celebrating womanhood and nature, the Bonalu festival in Hyderabad, and exquisite Dokra metal crafts.`,
      kerala: `Kerala, known as "God's Own Country," is internationally renowned for classical Kathakali and Mohiniyattam dances, the grand harvest festival of Onam with boat races (Vallamkali) and Pookkalam flower carpets, ancient martial art Kalaripayattu, and spice plantations that shaped world trade for millennia.`,
      temple: `Temples in Indian heritage are not merely places of worship\u2014they were epicenter hubs of Vedic education, classical dance, music, sculpture, astronomy, and community charity. Key architectural components include the Gopuram (towering entrance), Garbhagriha (inner sanctum holding the deity), Mandapa (pillared assembly hall), and Vimana (tower over the sanctum).`
    };
    const lowerMsg = message.toLowerCase();
    let fallback = "Namaste! Welcome to Bharat Heritage. India is a land of incredible diversity across 28 states and 8 union territories. Each state preserves unique languages, traditional arts, majestic monuments, and soul-stirring festivals that have united families across millennia.";
    if (lowerMsg.includes("andhra") || lowerMsg.includes("tirupati") || lowerMsg.includes("kuchipudi")) {
      fallback = fallbackAnswers.andhra;
    } else if (lowerMsg.includes("telangana") || lowerMsg.includes("bathukamma") || lowerMsg.includes("ramappa")) {
      fallback = fallbackAnswers.telangana;
    } else if (lowerMsg.includes("kerala") || lowerMsg.includes("kathakali") || lowerMsg.includes("onam")) {
      fallback = fallbackAnswers.kerala;
    } else if (lowerMsg.includes("temple") || lowerMsg.includes("gopuram") || lowerMsg.includes("architecture")) {
      fallback = fallbackAnswers.temple;
    }
    res.json({
      reply: fallback,
      source: "knowledge-base",
      note: "Tip: Add GEMINI_API_KEY in Settings > Secrets for dynamic real-time AI responses across all languages!"
    });
  } catch (error) {
    console.error("Error in /api/chat:", error);
    res.status(500).json({
      error: "Unable to generate response at this time.",
      details: error.message
    });
  }
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Bharat Heritage Server running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
